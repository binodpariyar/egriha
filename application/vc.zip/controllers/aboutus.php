<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Aboutus extends CI_Controller {
	public function index()
	{
		$data['main'] = 'pages/aboutus';
		$this->load->view('index',$data);
	}

	
}