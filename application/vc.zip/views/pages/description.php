

  <div id="main_secondary">
    <div class="service_wrapper">
  <div id="provide">
     <h3>House sell for Kalanki at 200,00,000</h3></a>
     <hr />
    <div id="housesell">
      <div id="contenttwo">
        <div class="entry-selling description">
          
          <div class="entry_body">
            
             <a href="<?php echo base_url('description'); ?>"><img src="<?php echo base_url('front_assets/images/sellthree.jpg');?>" alt="" /></a>
             <div class="short_description"> 
               <ul>
                  <li>Kantipur Colony.</li>
                    <li>800 M Far From Kuleshwor Ganeshsthan.</li>
                    <li>Beautiful House 3/5 Floors</li>
                    <li>800 M Far From Kuleshwor Ganeshsthan.</li>
                    <li>Bed Room 2.With Attched Bathroom.Kantipur Colony.</li>
                           <li>Beautiful House 3/5 Floors</li>
               </ul>


             </div>
               
            
            <div class="entry_body_spec">
              

              
              <ul>
                <li>Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.Kantipur Colony.</li><br> 
                  <li>
                  Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
                  With Attched Bathroom.
                  </li>
                  
                </ul>
              </div>
              
            </div><!-- project entry content ends -->
            
          </div><!-- project entry ends -->

            
          </div><!-- content ends -->


        </div>
    
  </div>

    

  </div>

  <div class="ad">

            <ul class="ads_slider">
  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringad.jpeg');?>">

  </li>
  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringadone.jpg');?>">
    </li>

  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringadtwo.jpg');?>">
    </li>

  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringadone.jpg');?>">

  </li>

  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringadone.jpg');?>">
    </li>

  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringadtwo.jpg');?>">
    </li>

  <li>
    <img src="<?php echo base_url('front_assets/images/engineeringadone.jpg');?>">

  </li>

  </ul>
    



    </div>


<div class="projects margin_up_20">

  <ul class="house_pic" id="selling">
    <li>
      <img src="<?php echo base_url('front_assets/images/engineeringthree.jpg'); ?>">
      <span>Commerial house</span>
     <!--  <span>Rs.750000/-</span> -->
      <span>Lazimpat Kathmandu</span>
    </li>
    <li>
      <img src="<?php echo base_url('front_assets/images/sellthree.jpg'); ?>">
      <span>Commerial house</span>
      <!-- <span>Rs.7510000/-</span> -->
      <span>Lazimpat Kathmandu</span>
    </li>
    <li>
      <img src="<?php echo base_url('front_assets/images/civilhome.jpg'); ?>">
      <span>Civil Home</span>
      <!-- <span>Rs.1550000/-</span> -->
      <span>Lazimpat Kathmandu</span>
    </li>
    <li>
      <img src="<?php echo base_url('front_assets/images/engineeringthree.jpg'); ?>">
      <span>Commerial house</span>
     <!--  <span>Rs.750000/-</span> -->
      <span>Lazimpat Kathmandu</span>
    </li>
    <li>
      <img src="<?php echo base_url('front_assets/images/sellthree.jpg'); ?>">
      <span>Commerial house</span>
      <!-- <span>Rs.7510000/-</span> -->
      <span>Lazimpat Kathmandu</span>
    </li>
    <li>
      <img src="<?php echo base_url('front_assets/images/civilhome.jpg'); ?>">
      <span>Civil Home</span>
      <!-- <span>Rs.1550000/-</span> -->
      <span>Lazimpat Kathmandu</span>
    </li>

  </ul>



</div>








  </div>

