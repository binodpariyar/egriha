<div id="main_secondary">
	<div class="client_detail">
		<div class="entry_body_client">
          <h3>Client Detail</h3>
          
          <img src="<?php echo base_url('front_assets/images/clientone.jpg');?>" alt="" />
          <div class="entry_body_spec_client">
          
           <ul>
            <li>Prakash Thapa</li>
            <li>Tripureswor,Kathmandu</li>
            <li>977-9808575482</li>
          </ul>
        </div>
         
          
        </div>
</div>

<div class="progress"> 
	<div class="entry-selling-client">
				<div class="entry_top"><!-- top design --></div>
				<div class="entry_body_client_two">
					<img src="<?php echo base_url('front_assets/images/civilhomeone.jpg');?>" alt="" />
					<h3>Project one</h3>
					 
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore</p>
						
				
					
					
					<div class="entry_body_spec_client_two">
					<h3>Tasks</h3>
					 <ul>
						<li>(Plan 1) Constructing civil homes in Bhaktapur.</li>
						<li>(Plan 2) Constructing civil homes in Old baneswor.</li>
						<li>Price is Starting from Rs.750000/-</li>
						
					</ul></div>
					
					
				</div><!-- project entry content ends -->
				<div class="entry_bottom"><!-- bottom design --></div>
			</div><!-- project entry ends -->



				<div class="entry-selling-client">
				<div class="entry_top"><!-- top design --></div>
				<div class="entry_body_client_two">
					<img src="<?php echo base_url('front_assets/images/civilhome.jpg');?>" alt="" />
					<h3>Project two</h3>
					 
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore</p>
						
				
					
					
					<div class="entry_body_spec_client_two">
					<h3>Tasks</h3>
					 <ul>
						<li>(Plan 1) Constructing civil homes in Butwal.</li>
						<li>(Plan 2) Constructing civil homes in Chitwan.</li>
						<li>Price is Starting from Rs.450000/-</li>
						
					</ul></div>
					
					
				</div><!-- project entry content ends -->
				<div class="entry_bottom"><!-- bottom design --></div>
			</div><!-- project entry ends -->





</div>



</div>