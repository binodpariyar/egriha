          <div id="main_secondary"><!-- Main Content -->
            <div id="content_form"><!-- Content Starts -->
              <h2>Forget Password?</h2>
              <hr />

              <div class="entry">
                <div class="entry_top"><!--top design --></div>
                <div class="entry_body">


                 <form method="post" action="#" id="contactform">


                  <div>
                   <label for="email"><strong>Enter your email address:</strong></label>
                   <input type="email" size="50" name="email" id="email" required="required"  />
                 </div>

              
                 <div style="margin-top:10px;">
                   <input type="submit" class="submit" value="Submit" name="submit" />
                 </div>

               

              </form>
            </div><!-- entry body ends -->
            <div class="entry_bottom"><!-- bottom design --></div>
          </div>
        </div><!-- Content Ends -->

      </div>