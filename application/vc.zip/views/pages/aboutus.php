

<div id="main_secondary">
  <div class="service_wrapper">
<div id="provide">
  <h2>About us</h2>
   <hr />
 <p>Local knowledge, global expertise.</p>
 <p>Whether you are constructing, buying, selling or renting a property in Nepal, our comprehensive and qualified team at grihanepal is on hand to help you in every step of your way, time you first get in touch with us until the final moment we hand over the keys to your new home.</p>
  <p>You can rely on us because we are the team of architects, engineers, valuators, Builders and consulters: simply a team of technically sound professionals.</p>
  <p>We believe there should be 100% transparency between you and us. Personal and professional customer services are on high priority of our list of services. We know how precious is your time, so do not waste with unnecessary appointments or phone calls and instead spend our energy in finding you the right property, buyer or tenant. Striving to be different from others in the market, we want to make your experience with us as effective and profitable as possible</p>
</div>

  

</div>

<div class="ad">

          <ul class="ads_slider">
          <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint.jpg');?>">

        </li>
        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint2.jpg');?>">
        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint3.jpg');?>">
        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint4.jpg');?>">

        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint.jpg');?>">

        </li>
        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint2.jpg');?>">
        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint3.jpg');?>">
        </li>

       
</ul>
  



  </div>






</div>

