<div id="main_secondary">

	<ul class="house_pic" id="selling">

		<li>
			<a href="<?php echo base_url('description'); ?>">
			<img src="<?php echo base_url('front_assets/images/engineeringthree.jpg'); ?>">
			<span>Commerial house</span>
	<!-- 		<span>Rs.750000/-</span> -->
			<span>Lazimpat Kathmandu</span></a>
		</li>
		<li>
			<a href="<?php echo base_url('description'); ?>">
			<img src="<?php echo base_url('front_assets/images/sellthree.jpg'); ?>">
			<span>Commerial house</span>
		<!-- 	<span>Rs.7510000/-</span> -->
			<span>Lazimpat Kathmandu</span></a>
		</li>
		<li>
			<a href="<?php echo base_url('description'); ?>">
			<img src="<?php echo base_url('front_assets/images/civilhome.jpg'); ?>">
			<span>Civil Home</span>
		<!-- 	<span>Rs.1550000/-</span> -->
			<span>Lazimpat Kathmandu</span></a>
		</li>
		<li>
			<a href="<?php echo base_url('description'); ?>">
			<img src="<?php echo base_url('front_assets/images/engineeringthree.jpg'); ?>">
			<span>Commerial house</span>
	<!-- 		<span>Rs.750000/-</span> -->
			<span>Lazimpat Kathmandu</span></a>
		</li>
		<li>
			<a href="<?php echo base_url('description'); ?>">
			<img src="<?php echo base_url('front_assets/images/sellthree.jpg'); ?>">
			<span>Commerial house</span>
		<!-- 	<span>Rs.7510000/-</span> -->
			<span>Lazimpat Kathmandu</span></a>
		</li>
		<li>
			<a href="<?php echo base_url('description'); ?>">
			<img src="<?php echo base_url('front_assets/images/civilhome.jpg'); ?>">
			<span>Civil Home</span>
		<!-- 	<span>Rs.1550000/-</span> -->
			<span>Lazimpat Kathmandu</span></a>
		</li>

	</ul>









	<div id="housesell">
		<div id="contenttwo">
			<div class="entry-selling">
				
				<div class="entry_body">

					<a href="<?php echo base_url('description'); ?>">
					<img src="<?php echo base_url('front_assets/images/sellfour.jpg');?>" alt="" />
					<div class="entry_body_spec">
						<h5>House sell for Chandol at 200,00,000</h5></a>

						
						<ul>
							<li>Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
								With Attched Bathroom</li>		
								
							</ul>
						</div>
						
					</div><!-- project entry content ends -->
					
				</div><!-- project entry ends -->


				<div class="entry-selling">
					
					<div class="entry_body">

						<a href="<?php echo base_url('description'); ?>">
						<img src="<?php echo base_url('front_assets/images/sellthree.jpg');?>" alt="" />
						<div class="entry_body_spec">
							<h5>House sell for Kalanki at 250,00,000</h5></a>
								<ul>
								<li>It Is Near The Shree Samag Bhawan.....due To Money Problrem I Want To Sell... It Is Beautiful</li>		
								
							</ul>
						</div>
						
					</div><!-- project entry content ends -->
					
				</div><!-- project entry ends -->


				<div class="entry-selling">
					
					<div class="entry_body">

						<a href="<?php echo base_url('description'); ?>">
						<img src="<?php echo base_url('front_assets/images/selltwo.jpg');?>" alt="" />
						<div class="entry_body_spec">
							<h5>House sell for Baluwatar at 100,00,000</h5></a>

							
							<ul>
								<li>Kantipur Colony , 800 M Far From Kuleshwor Ganeshsthan. Beautiful House 3/5 Floors,bed Room 2
									With Attched Bathroom</li>		
									
								</ul>
							</div>
							
						</div><!-- project entry content ends -->
						
					</div><!-- project entry ends -->

					<div class="entry-selling">
						
						<div class="entry_body">
							<a href="<?php echo base_url('description'); ?>">
							<img src="<?php echo base_url('front_assets/images/sellone.jpg');?>" alt="" />
							<div class="entry_body_spec">
								<h5>House sell for Panipokhari at 400,00,000</h5></a>

								
								<ul>
									<li>It Is Near The Shree Samag Bhawan.....due To Money Problrem I Want To Sell... It Is Beautiful</li>		
									
								</ul>
							</div>
							
						</div><!-- project entry content ends -->
						
					</div><!-- project entry ends -->

					<div class="entry-selling">
						
						<div class="entry_body">

							<a href="<?php echo base_url('description'); ?>">
							<img src="<?php echo base_url('front_assets/images/sellfour.jpg');?>" alt="" />
							<div class="entry_body_spec">
								<h5>House sell for Samakhusi at 95,00,000</h5></a>

								
								<ul>
									<li>It Is Near The Shree Samag Bhawan.....due To Money Problrem I Want To Sell... It Is Beautiful</li>		
									
								</ul>
							</div>
							
						</div><!-- project entry content ends -->
						
					</div><!-- project entry ends -->

					<div class="entry-selling">
						
						<div class="entry_body">

							<a href="<?php echo base_url('description'); ?>">
							<img src="<?php echo base_url('front_assets/images/sellthree.jpg');?>" alt="" />
							<div class="entry_body_spec">
								<h5>House sell for Basundhara at 90,00,000</h5></a>

								
								<ul>
									<li>It Is Near The Shree Samag Bhawan.....due To Money Problrem I Want To Sell... It Is Beautiful</li>		
									
								</ul>
							</div>
							
						</div><!-- project entry content ends -->
						
					</div><!-- project entry ends -->
					<div class="entry-selling">
						
						<div class="entry_body">

							<a href="<?php echo base_url('description'); ?>">
							<img src="<?php echo base_url('front_assets/images/selltwo.jpg');?>" alt="" />
							<div class="entry_body_spec">
								<h5>House sell for Maharajgunj at 400,00,000</h5></a>

								
								<ul>
									<li>It Is Near The Shree Samag Bhawan.....due To Money Problrem I Want To Sell... It Is Beautiful</li>		
									
								</ul>
							</div>
							
						</div><!-- project entry content ends -->
						
					</div><!-- project entry ends -->
					<div class="entry-selling">
						
						<div class="entry_body">

							<a href="<?php echo base_url('description'); ?>">
							<img src="<?php echo base_url('front_assets/images/sellthree.jpg');?>" alt="" />
							<div class="entry_body_spec">
								<h5>House sell for Jorpati at 200,00,000</h5></a>

								
								<ul>
									<li>It Is Near The Shree Samag Bhawan.....due To Money Problrem I Want To Sell... It Is Beautiful</li>		
									
								</ul>
							</div>
							
						</div><!-- project entry content ends -->
						
					</div><!-- project entry ends -->


					
				</div><!-- content ends -->


			</div>
			<!-- <div id="sellbox">Sell box</div> -->

				<div class="ad">

		  <ul class="ads_slidertwo">
       <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint.jpg');?>">

        </li>
        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint2.jpg');?>">
        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint3.jpg');?>">
        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint4.jpg');?>">

        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint.jpg');?>">

        </li>
        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint2.jpg');?>">
        </li>

        <li>
          <img src="<?php echo base_url('front_assets/images/asianpaint3.jpg');?>">
        </li>


</ul>




	</div>

<script type="text/javascript">

$(document).ready(function(){
  // alert('binod');
  $('.house_pic').bxSlider({
    minSlides: 5,
    maxSlides: 5,
    slideWidth: 200,
    slideMargin: 5,
    controls:true,
    auto : true
  });
});

</script>




		</div>



	