<form class="horizontal-form col-md-6">
	 <p class="form-group">
	 	
	 	<label>Content:</label>
	 	<textarea style="height:200px;">
	 		
	 	</textarea>


	 </p>
	
	 <div class="col-md-3 pull-left button">
	 	<input class="btn btn-primary" value="submit" type="submit">
	 </div>
</form>