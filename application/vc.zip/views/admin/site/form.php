<form class="horizontal-form col-md-4">
	 <p class="form-group">
	 	
	 	<label>Facebook:</label>
	 	<input class="form-control">


	 </p>
	 <p class="form-group">
	 	
	 	<label>Google:</label>
	 	<input class="form-control">


	 </p>
	 <p class="form-group">
	 	
	 	<label>Twitter:</label>
	 	<input class="form-control">


	 </p>

	 <div class="col-md-3 pull-left button">
	 	<input class="btn btn-primary" value="submit" type="submit">
	 </div>
</form>