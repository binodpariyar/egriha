<div id="main_secondary">

	<div class="progress">
	
		<h1>Welcome to user Dashboard</h1>
		
		<?php //debug($this->ion_auth->user()->row());exit; ?>
	
	</div>

	<div class="client_detail">
		
		<?php //debug($this->details); ?>

	</div>

</div>